"""Cách dùng model đã đóng gói. Chạy từ thư mục gốc của dự án:

    python using_model.py 5 10
"""
import sys
from pathlib import Path

from ml.predict import Predictor

ZIP_PATH = Path("models") / "recommender.zip"

if __name__ == "__main__":
    customer_id = int(sys.argv[1])
    k = int(sys.argv[2]) if len(sys.argv) > 2 else 10

    predictor = Predictor(ZIP_PATH)
    for rank, rec in enumerate(predictor.recommend(customer_id, k), start=1):
        print(f"{rank:2d}. {rec.title} - {rec.artist} ({rec.score:.3f})")
